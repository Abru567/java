
public enum PaloCartas {
    ESPADAS,
    BASTOS,
    OROS,
    COPAS;
}
